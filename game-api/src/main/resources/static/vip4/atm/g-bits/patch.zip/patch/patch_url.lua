return {
  "http://atmdl.leiting.com/g-bits",
}